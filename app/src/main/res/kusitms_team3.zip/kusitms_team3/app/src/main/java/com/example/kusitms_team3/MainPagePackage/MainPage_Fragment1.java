package com.example.kusitms_team3.MainPagePackage;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.kusitms_team3.R;


public class MainPage_Fragment1 extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
    View rootview =  inflater.inflate(R.layout.fragment_main_page_1, container, false);

        //여기다가 코드 쓰면됨


        return rootview;
    }
}